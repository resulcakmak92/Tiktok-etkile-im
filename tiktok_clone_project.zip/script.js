document.getElementById('likes').addEventListener('click', function() {
    const link = document.getElementById('link').value;
    if (link) {
        sendRequest('likes', link);
    } else {
        alert('Lütfen bir TikTok linki girin!');
    }
});

document.getElementById('followers').addEventListener('click', function() {
    const link = document.getElementById('link').value;
    if (link) {
        sendRequest('followers', link);
    } else {
        alert('Lütfen bir TikTok linki girin!');
    }
});

document.getElementById('views').addEventListener('click', function() {
    const link = document.getElementById('link').value;
    if (link) {
        sendRequest('views', link);
    } else {
        alert('Lütfen bir TikTok linki girin!');
    }
});

function sendRequest(type, link) {
    fetch('http://localhost:3000/addInteraction', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ type, link })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`${type} ekleme işlemi başarılı!`);
        } else {
            alert('İşlem başarısız!');
        }
    })
    .catch(error => {
        console.error('Hata:', error);
        alert('Bir hata oluştu. Lütfen tekrar deneyin.');
    });
}