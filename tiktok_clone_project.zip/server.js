const express = require('express');
const scrapeTikTokData = require('./scrapeTikTok');
const mongoose = require('mongoose');
const Interaction = require('./interactionModel');
const app = express();

app.use(express.json());

// MongoDB bağlantısı
require('./db');

// Etkileşim işlemi
app.post('/addInteraction', async (req, res) => {
    const { type, link } = req.body;
    let response;
    const interaction = new Interaction({ type, link });

    try {
        // Veritabanına etkileşim kaydını ekliyoruz
        await interaction.save();

        // TikTok verilerini çekme
        const tiktokData = await scrapeTikTokData(link);
        if (!tiktokData) {
            throw new Error('TikTok verisi alınamadı');
        }

        // Durumu belirleme
        if (type === 'likes') {
            response = { success: true, likes: tiktokData.likes };
        } else if (type === 'followers') {
            response = { success: true, message: 'Takipçi ekleme işlemi başarılı!' };
        } else if (type === 'views') {
            response = { success: true, views: tiktokData.views };
        }

        // İşlem durumunu güncelle
        interaction.status = 'completed';
        await interaction.save();
        res.json(response);
    } catch (error) {
        console.error('Hata:', error);
        interaction.status = 'failed';
        await interaction.save();
        res.status(500).json({ message: error.message || 'Bir hata oluştu. Lütfen tekrar deneyin.' });
    }
});

// Server başlatma
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
